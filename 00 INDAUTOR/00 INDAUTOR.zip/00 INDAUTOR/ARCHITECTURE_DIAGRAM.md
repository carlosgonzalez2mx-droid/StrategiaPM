# 🏗️ Diagrama de Arquitectura - StrategiaPM Dashboard

## 📊 Arquitectura General del Sistema

```mermaid
graph TB
    %% Usuario y Navegador
    User[👤 Usuario] --> Browser[🌐 Navegador Web]
    
    %% Frontend React
    Browser --> ReactApp[⚛️ React Application]
    
    %% Componentes Principales
    ReactApp --> App[📱 App.js - Componente Principal]
    App --> AuthContext[🔐 AuthContext - Autenticación]
    App --> ProjectContext[📋 ProjectContext - Estado Global]
    
    %% Servicios
    App --> SupabaseService[🗄️ SupabaseService - Backend]
    App --> FilePersistence[💾 FilePersistenceService - Local Storage]
    App --> RiskService[⚠️ RiskCalculationService - Cálculos]
    
    %% Vistas Principales
    App --> Dashboard[📊 Dashboard Ejecutivo]
    App --> ProjectMgmt[🔧 Gestión de Proyectos]
    App --> Portfolio[📈 Portfolio Estratégico]
    App --> Reports[📋 Reportes]
    
    %% Componentes de Gestión
    ProjectMgmt --> Financial[💰 Gestión Financiera]
    ProjectMgmt --> Schedule[📅 Gestión de Cronograma]
    ProjectMgmt --> Risk[⚠️ Gestión de Riesgos]
    ProjectMgmt --> Resources[👥 Gestión de Recursos]
    
    %% Backend y Persistencia
    SupabaseService --> SupabaseDB[(🗄️ Supabase Database)]
    FilePersistence --> LocalStorage[(💾 Local Storage)]
    FilePersistence --> IndexedDB[(🗃️ IndexedDB)]
    
    %% Servicios Externos
    SupabaseService --> SupabaseAuth[🔑 Supabase Auth]
    SupabaseService --> SupabaseStorage[📁 Supabase Storage]
    
    %% Estilos y UI
    ReactApp --> Tailwind[🎨 Tailwind CSS]
    ReactApp --> Charts[📊 Chart.js / React-Chartjs-2]
    
    %% Estructura de Datos
    ProjectContext --> Projects[📋 Proyectos]
    ProjectContext --> Tasks[✅ Tareas]
    ProjectContext --> Risks[⚠️ Riesgos]
    ProjectContext --> Financial[💰 Datos Financieros]
    
    %% Clases de estilos
    classDef frontend fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    classDef backend fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    classDef storage fill:#e8f5e8,stroke:#1b5e20,stroke-width:2px
    classDef services fill:#fff3e0,stroke:#e65100,stroke-width:2px
    
    class ReactApp,App,AuthContext,ProjectContext,Dashboard,ProjectMgmt,Portfolio,Reports,Financial,Schedule,Risk,Resources frontend
    class SupabaseService,SupabaseDB,SupabaseAuth,SupabaseStorage backend
    class FilePersistence,LocalStorage,IndexedDB storage
    class RiskService,Tailwind,Charts services
```

## 🏛️ Arquitectura por Capas

```mermaid
graph TB
    subgraph "🎨 Capa de Presentación"
        UI[🖥️ Interfaz de Usuario]
        Components[🧩 Componentes React]
        Charts[📊 Gráficos y Visualizaciones]
    end
    
    subgraph "⚙️ Capa de Lógica de Negocio"
        Contexts[🔄 Contextos de Estado]
        Services[🛠️ Servicios de Negocio]
        Calculations[🧮 Cálculos y Métricas]
    end
    
    subgraph "💾 Capa de Datos"
        LocalData[💾 Datos Locales]
        CloudData[☁️ Datos en la Nube]
        Cache[⚡ Cache y Sincronización]
    end
    
    subgraph "🔌 Capa de Integración"
        SupabaseAPI[🗄️ API de Supabase]
        FileSystem[📁 Sistema de Archivos]
        ExternalAPIs[🌐 APIs Externas]
    end
    
    UI --> Components
    Components --> Contexts
    Contexts --> Services
    Services --> Calculations
    Services --> LocalData
    Services --> CloudData
    LocalData --> Cache
    CloudData --> SupabaseAPI
    LocalData --> FileSystem
    Services --> ExternalAPIs
```

## 📱 Estructura de Componentes

```mermaid
graph TD
    App[📱 App.js] --> Sidebar[📋 Sidebar]
    App --> MainContent[📄 Contenido Principal]
    
    MainContent --> Dashboard[📊 Dashboard Ejecutivo]
    MainContent --> ProjectMgmt[🔧 Gestión de Proyectos]
    MainContent --> Portfolio[📈 Portfolio]
    MainContent --> Reports[📋 Reportes]
    
    %% Dashboard Ejecutivo
    Dashboard --> ConsolidatedDashboard[📊 ConsolidatedDashboard]
    ConsolidatedDashboard --> PortfolioCharts[📈 PortfolioCharts]
    ConsolidatedDashboard --> ConsolidatedCashFlow[💰 ConsolidatedCashFlow]
    ConsolidatedDashboard --> CorporateAlerts[🚨 CorporateAlerts]
    
    %% Gestión de Proyectos
    ProjectMgmt --> ProjectManagementTabs[📑 ProjectManagementTabs]
    ProjectManagementTabs --> FinancialManagement[💰 FinancialManagement]
    ProjectManagementTabs --> ScheduleManagement[📅 ScheduleManagement]
    ProjectManagementTabs --> RiskManagement[⚠️ RiskManagement]
    ProjectManagementTabs --> ResourceManagement[👥 ResourceManagement]
    
    %% Portfolio
    Portfolio --> PortfolioDashboard[📈 PortfolioDashboard]
    Portfolio --> PortfolioStrategic[🎯 PortfolioStrategic]
    Portfolio --> PortfolioSettings[⚙️ PortfolioSettings]
    
    %% Reportes
    Reports --> ReportsManagement[📋 ReportsManagement]
    Reports --> ProjectAudit[🔍 ProjectAudit]
    Reports --> ProjectArchive[📦 ProjectArchive]
    
    %% Componentes de Soporte
    App --> LoginForm[🔐 LoginForm]
    App --> FileManager[📁 FileManager]
    App --> BackupManager[💾 BackupManager]
    App --> UserManagement[👤 UserManagement]
```

## 🔄 Flujo de Datos

```mermaid
sequenceDiagram
    participant U as 👤 Usuario
    participant UI as 🖥️ Interfaz
    participant C as 🔄 Context
    participant S as 🛠️ Servicio
    participant DB as 🗄️ Base de Datos
    
    U->>UI: Interactúa con la aplicación
    UI->>C: Actualiza estado local
    C->>S: Solicita operación
    S->>DB: Consulta/Actualiza datos
    DB-->>S: Retorna datos
    S-->>C: Procesa respuesta
    C-->>UI: Actualiza estado global
    UI-->>U: Muestra resultado actualizado
    
    Note over S,DB: Sincronización automática<br/>con Supabase
    Note over C,UI: Estado reactivo<br/>se actualiza automáticamente
```

## 🛠️ Stack Tecnológico

### Frontend
- **React 19.1.1** - Framework principal
- **React Router DOM 7.8.2** - Navegación
- **Tailwind CSS 4.1.12** - Estilos
- **Chart.js 4.5.0** - Gráficos
- **Lucide React 0.540.0** - Iconos

### Backend y Servicios
- **Supabase 2.57.4** - Backend as a Service
- **Supabase Auth** - Autenticación
- **Supabase Storage** - Almacenamiento de archivos

### Persistencia Local
- **Local Storage** - Datos de sesión
- **IndexedDB** - Datos offline
- **File System API** - Archivos locales

### Herramientas de Desarrollo
- **React Scripts 5.0.1** - Build y desarrollo
- **Vercel** - Despliegue
- **XLSX 0.18.5** - Importación/Exportación Excel

## 📊 Métricas y Características

- **Componentes React**: 40+ componentes modulares
- **Contextos**: 2 contextos principales (Auth, Project)
- **Servicios**: 3 servicios especializados
- **Persistencia**: Híbrida (Local + Cloud)
- **Autenticación**: Multi-tenant con Supabase
- **Offline**: Soporte completo con sincronización
- **Responsive**: Diseño adaptativo con Tailwind

## 🔒 Seguridad y Permisos

- **Autenticación JWT** via Supabase
- **Row Level Security (RLS)** en base de datos
- **Gestión de roles** (Admin, PM, Usuario)
- **Validación de datos** en frontend y backend
- **Cifrado** de datos sensibles

## 📈 Escalabilidad

- **Arquitectura modular** para fácil mantenimiento
- **Estado centralizado** con Context API
- **Servicios desacoplados** para reutilización
- **Persistencia híbrida** para rendimiento
- **Caching inteligente** para optimización
